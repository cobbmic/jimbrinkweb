Flask-BasicAuth
===============

|build status|_

.. |build status| image:: https://secure.travis-ci.org/jpvanhal/flask-basicauth.png?branch=master
   :alt: Build Status
.. _build status: http://travis-ci.org/jpvanhal/flask-basicauth

Flask-BasicAuth is a Flask extension that provides an easy way to protect
certain views or your whole application with HTTP `basic access
authentication`_.

.. _basic access authentication: http://en.wikipedia.org/wiki/Basic_access_authentication


Links
-----

- `Documentation <http://flask-basicauth.readthedocs.org/>`_
- `Issue Tracker <http://github.com/jpvanhal/flask-basicauth/issues>`_
- `Code <http://github.com/jpvanhal/flask-basicauth/>`_
- `Development Version
  <http://github.com/jpvanhal/flask-basicauth/zipball/master#egg=Flask-BasicAuth-dev>`_


Changelog
---------

Here you can see the full list of changes between each Flask-BasicAuth
release.

0.2.0 (June 15, 2013)
^^^^^^^^^^^^^^^^^^^^^

- Added Python 3 support.

0.1.1 (May 20, 2013)
^^^^^^^^^^^^^^^^^^^^

- Fixed an issue where attempting to authenticate with password containing one
  or more colons was failing with "too many values to unpack" error (Michael
  Wallace).

0.1.0 (April 30, 2012)
^^^^^^^^^^^^^^^^^^^^^^

- Initial public release


